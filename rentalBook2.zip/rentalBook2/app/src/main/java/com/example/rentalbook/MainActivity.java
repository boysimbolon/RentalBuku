package com.example.rentalbook;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity implements ListView.OnItemClickListener{
    private String JSON_STRING;
    private ListView listView;
    private TextView tvuser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listView);
        listView.setOnItemClickListener(this);
        tvuser = findViewById(R.id.tvUser);
        getDataBuku();
    }

    private void getDataBuku() {
        class GetJSON extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(MainActivity.this,"Mengambil Data","Mohon Tunggu...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                JSON_STRING = s;
                ArrayList<HashMap<String,String>> list = new ArrayList<>();
                try {
                    // Mengonversi string JSON menjadi objek JSONObject
                    JSONObject jsonObject = new JSONObject(JSON_STRING);

                    // Mengambil array "result" dari objek JSONObject
                    JSONArray result = jsonObject.getJSONArray("result");

                    // Loop melalui setiap objek dalam array "result"
                    for(int i = 0; i < result.length(); i++) {
                        // Mengambil objek buku pada indeks ke-i
                        JSONObject jo = result.getJSONObject(i);
                        konfigurasi.KEY_NAMA = jo.getString("namalengkap");
                        tvuser.setText(konfigurasi.KEY_NAMA);
                        // Mendapatkan nilai dari setiap atribut buku
                        String id = jo.getString("id");
                        String judul = jo.getString("judul");
                        String penulis = jo.getString("penulis");
                        String genre = jo.getString("genre");
                        String tahun = jo.getString("tahun");
                        String hargasewa = jo.getString("hargasewa");
                        String deskription = jo.getString("deskription");

                        // Membuat hashmap untuk menyimpan data buku
                        HashMap<String,String> buku = new HashMap<>();
                        buku.put("id", id);
                        buku.put("judul", judul);
                        buku.put("penulis", penulis);
                        buku.put("genre", genre);
                        buku.put("tahun", tahun);
                        buku.put("hargasewa", hargasewa);
                        buku.put("deskription", deskription);
                        list.add(buku);
                    }

            } catch (JSONException e) {
                    e.printStackTrace();
                }

                // Membuat adapter untuk menampilkan data buku dalam ListView
                ListAdapter adapter = new SimpleAdapter(
                        MainActivity.this,
                        list,
                        R.layout.itemlist,
                        new String[]{"id", "judul", "penulis", "genre", "tahun", "hargasewa","deskription"},
                        new int[]{R.id.ids, R.id.judul, R.id.penulis, R.id.genre, R.id.tahun, R.id.harga,R.id.description}
                );

                // Mengatur adapter ke dalam ListView
                listView.setAdapter(adapter);
            }

            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestParam(konfigurasi.URL_GET_ALL,konfigurasi.KEY_ID);
                return s;
            }
        }
        GetJSON gj = new GetJSON(); gj.execute();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        HashMap<String,String> map = (HashMap) parent.getItemAtPosition(position);
        String IdBuku = map.get("id").toString();
        String judulBuku = map.get("judul").toString();
        String penulisBuku = map.get("penulis").toString();
        String genreBuku = map.get("genre").toString();
        String tahunBuku = map.get("tahun").toString();
        String hargaBuku = map.get("hargasewa").toString();
        String descriptionBuku = map.get("deskription").toString();

        konfigurasi.IdBuku = IdBuku;
        konfigurasi.judulBuku = judulBuku;
        konfigurasi.penulisBuku = penulisBuku;
        konfigurasi.genreBuku = genreBuku;
        konfigurasi.tahunBuku = tahunBuku;
        konfigurasi.hargaBuku = hargaBuku;
        konfigurasi.description = descriptionBuku;

        Intent intent = new Intent(MainActivity.this, TampilDetailBuku.class);
        startActivity(intent);
    }
    public void myrental(View V){
        Intent intent = new Intent(MainActivity.this,MyRental.class);
        startActivity(intent);
        finish();
    }
    public void keluar(View V){
        Intent intent = new Intent(MainActivity.this,Login.class);
        startActivity(intent);
        finish();
    }
}