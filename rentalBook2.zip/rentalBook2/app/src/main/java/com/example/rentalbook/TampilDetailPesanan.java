package com.example.rentalbook;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;

public class TampilDetailPesanan extends AppCompatActivity {
    private TextView judul,penulis,genre,harga,deskription,tahun;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tampil_detail_pesanan);
        judul = findViewById(R.id.judulDetails);
        penulis = findViewById(R.id.penulisDetails);
        harga = findViewById(R.id.hargaDetails);
        tahun = findViewById(R.id.tahunDetails);
        genre = findViewById(R.id.genreDetails);
        deskription = findViewById(R.id.deskriptionDetail);
        judul.setText("JUDUL : "+konfigurasi.judulBuku);
        penulis.setText("PENULIS : "+konfigurasi.penulisBuku);
        genre.setText("GENRE : "+konfigurasi.genreBuku);
        tahun.setText("TAHUN : "+konfigurasi.tahunBuku);
        deskription.setText("DESCRIPTION : "+konfigurasi.description);
        harga.setText("HARGA SEWA : "+konfigurasi.hargaBuku);
    }
    public void kembalis(View v){
        Intent intent = new Intent(TampilDetailPesanan.this,MyRental.class);
        startActivity(intent);
    }
    public void edit(View v){
        Intent intent = new Intent(TampilDetailPesanan.this,FormRentalEdit.class);
        startActivity(intent);
    }
    public void hapus(View v){
        class Sewalah extends AsyncTask<Void, Void, String> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(TampilDetailPesanan.this, "Sewa...", "Please wait...", false, false);
            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String, String> params = new HashMap<>();
                params.put("idUser", konfigurasi.KEY_ID);
                params.put("idBuku", konfigurasi.IdBuku);
                RequestHandler rh = new RequestHandler();
                String res = rh.sendPostRequest(konfigurasi.URL_DELETE, params);
                return res;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                // Dismiss progress dialog
                loading.dismiss();
                // Check if the response string is not empty
                if (s != null && !s.isEmpty()) {
                    Intent intent = new Intent(TampilDetailPesanan.this, MainActivity.class);
                    Toast.makeText(TampilDetailPesanan.this, "Berhasil di hapus", Toast.LENGTH_SHORT).show();
                    startActivity(intent);
                } else {
                    // If response string is empty, show error message
                    Toast.makeText(TampilDetailPesanan.this, "GAGAL", Toast.LENGTH_SHORT).show();
                }
            }
        }
        Sewalah sewalah = new Sewalah();
        sewalah.execute();
    }
}