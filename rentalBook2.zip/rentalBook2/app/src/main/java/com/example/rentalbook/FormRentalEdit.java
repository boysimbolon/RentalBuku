package com.example.rentalbook;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class FormRentalEdit extends AppCompatActivity {
    private EditText sewa, kembali;
    private TextView harga;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_rental_edit);
        sewa = findViewById(R.id.tanggalsewas);
        kembali = findViewById(R.id.tanggalkembalis);
        harga= findViewById(R.id.hargaTotals);
        sewa.setText(konfigurasi.tSewa);
        kembali.setText(konfigurasi.tkembali);
    }
    public void Edits(View V){
        cekHargas(V);
        String Sewa = sewa.getText().toString().trim();
        String Kembali = kembali.getText().toString().trim();
        String Harga = harga.getText().toString().trim();
        class Sewalah extends AsyncTask<Void, Void, String> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(FormRentalEdit.this, "Sewa...", "Please wait...", false, false);
            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String, String> params = new HashMap<>();
                params.put("sewa", Sewa);
                params.put("harga", Harga);
                params.put("idUser", konfigurasi.KEY_ID);
                params.put("idBuku", konfigurasi.IdBuku);
                params.put("Tenggat", Kembali);
                RequestHandler rh = new RequestHandler();
                String res = rh.sendPostRequest(konfigurasi.URL_EDIT, params);
                return res;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                // Dismiss progress dialog
                loading.dismiss();
                // Check if the response string is not empty
                if (s != null && !s.isEmpty()) {
                    Intent intent = new Intent(FormRentalEdit.this, MainActivity.class);
                    Toast.makeText(FormRentalEdit.this, "Berhasil Edit", Toast.LENGTH_SHORT).show();
                    startActivity(intent);
                } else {
                    // If response string is empty, show error message
                    Toast.makeText(FormRentalEdit.this, "GAGAL", Toast.LENGTH_SHORT).show();
                }
            }
        }
        Sewalah sewalah = new Sewalah();
        sewalah.execute();
    }
    public void cekHargas(View V){
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        try {
            Date tglSewa = format.parse(sewa.getText().toString());
            Date tglKembali = format.parse(kembali.getText().toString());
            long diff = tglKembali.getTime() - tglSewa.getTime();
            if(diff<=0){
                Toast.makeText(this, "Tidak boleh tanggal sewa dengan tanggal pengembalian lebih kecil atau sama dengan", Toast.LENGTH_SHORT).show();
                return;
            }else{
                long diffDays = diff / (24 * 60 * 60 * 1000);
                int hargaBuku = Integer.parseInt(konfigurasi.hargaBuku);
                int total = (int) (diffDays * hargaBuku);
                harga.setText(String.valueOf(total)); // Mengubah total ke string sebelum ditampilkan di TextView
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
    public void kembalin(View V){
        Intent intent = new Intent(FormRentalEdit.this,TampilDetailBuku.class);
        startActivity(intent);
    }
}