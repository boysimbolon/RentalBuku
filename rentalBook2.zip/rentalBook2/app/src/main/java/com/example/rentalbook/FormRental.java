package com.example.rentalbook;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

public class FormRental extends AppCompatActivity {
    private EditText sewa, kembali;
    private TextView harga;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_rental);
        sewa = findViewById(R.id.tanggalsewa);
        kembali = findViewById(R.id.tanggalkembali);
        sewa.setText(konfigurasi.tglSewa);
        sewa.setText(konfigurasi.tglkembali);
        harga = findViewById(R.id.hargaTotal);
    }

    public void kembalilah(View V) {
        Intent intent = new Intent(this, TampilDetailBuku.class);
        startActivity(intent);
    }

    public void sewain(View v) {
        cekHarga(v);
        String Sewa = sewa.getText().toString().trim();
        String Kembali = kembali.getText().toString().trim();
        String Harga = harga.getText().toString().trim();
        class Sewalah extends AsyncTask<Void, Void, String> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(FormRental.this, "Sewa...", "Please wait...", false, false);
            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String, String> params = new HashMap<>();
                params.put("sewa", Sewa);
                params.put("harga", Harga);
                params.put("idUser", konfigurasi.KEY_ID);
                params.put("idBuku", konfigurasi.IdBuku);
                params.put("Tenggat", Kembali);
                RequestHandler rh = new RequestHandler();
                String res = rh.sendPostRequest(konfigurasi.URL_SEWA, params);
                return res;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                // Dismiss progress dialog
                loading.dismiss();
                // Check if the response string is not empty
                if (s != null && !s.isEmpty()) {
                    Intent intent = new Intent(FormRental.this, MainActivity.class);
                    Toast.makeText(FormRental.this, s, Toast.LENGTH_SHORT).show();
                    startActivity(intent);
                    finish();
                } else {
                    // If response string is empty, show error message
                    Toast.makeText(FormRental.this, "GAGAL", Toast.LENGTH_SHORT).show();
                }
            }
        }
        Sewalah sewalah = new Sewalah();
        sewalah.execute();
    }


    public void cekHarga(View v) {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        try {
            Date tglSewa = format.parse(sewa.getText().toString());
            Date tglKembali = format.parse(kembali.getText().toString());
            long diff = tglKembali.getTime() - tglSewa.getTime();
            if(diff<=0){
                Toast.makeText(this, "Tidak boleh tanggal sewa dengan tanggal pengembalian lebih kecil atau sama dengan", Toast.LENGTH_SHORT).show();
                return;
            }else{
            long diffDays = diff / (24 * 60 * 60 * 1000);
            int hargaBuku = Integer.parseInt(konfigurasi.hargaBuku);
            int total = (int) (diffDays * hargaBuku);
            harga.setText(String.valueOf(total)); // Mengubah total ke string sebelum ditampilkan di TextView
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public void datePicker(View v) {
        final EditText editText = (EditText) v;

        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (datePicker, year1, month1, dayOfMonth1) -> {
                    // Di sini kamu dapat menyimpan nilai tanggal yang dipilih
                    String selectedDate = dayOfMonth1 + "/" + (month1 + 1) + "/" + year1;
                    editText.setText(selectedDate); // Menampilkan tanggal di EditText
                },
                year,
                month,
                dayOfMonth
        );
        datePickerDialog.show();
    }

}
