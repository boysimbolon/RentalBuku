package com.example.rentalbook;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class TampilDetailBuku extends AppCompatActivity {
    private TextView judul,penulis,genre,harga,deskription,tahun;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tampil_detail_buku);
        judul = findViewById(R.id.judulDetail);
        penulis = findViewById(R.id.penulisDetail);
        harga = findViewById(R.id.hargaDetail);
        tahun = findViewById(R.id.tahunDetail);
        genre = findViewById(R.id.genreDetail);
        deskription = findViewById(R.id.deskriptionDetail);
        judul.setText("JUDUL : "+konfigurasi.judulBuku);
        penulis.setText("PENULIS : "+konfigurasi.penulisBuku);
        genre.setText("GENRE : "+konfigurasi.genreBuku);
        tahun.setText("TAHUN : "+konfigurasi.tahunBuku);
        deskription.setText("KETERANGAN : "+konfigurasi.description);
        harga.setText("HARGA SEWA : "+konfigurasi.hargaBuku);
    }
    public void Sewa(View V){
        Intent intent = new Intent(this, FormRental.class);
        startActivity(intent);
    }
    public void Kembali (View V){
        Intent intent =new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}