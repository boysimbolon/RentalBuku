package com.example.rentalbook;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;

public class Registrasi extends AppCompatActivity {
    private EditText email,nama,password,alamat,phone;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrasi);
        email = findViewById(R.id.email);
        nama = findViewById(R.id.namalengkap);
        password = findViewById(R.id.password);
        alamat = findViewById(R.id.alamat);
        phone = findViewById(R.id.notelepon);
    }
    public void Login(View V){
        Intent intent = new Intent(Registrasi.this, Login.class);
        startActivity(intent);
    }
    public void Regis(View V){
        final String Nama = nama.getText().toString().trim();
        final String Email = email.getText().toString().trim();
        final String Password= password.getText().toString().trim();
        final String Alamat= alamat.getText().toString().trim();
        final String Phone= phone.getText().toString().trim();

        if (Nama.isEmpty() || Email.isEmpty() || Password.isEmpty() || Alamat.isEmpty() || Phone.isEmpty() ) {
            Toast.makeText(getApplicationContext(), "Mohon lengkapi semua data", Toast.LENGTH_SHORT).show();
            return;
        }
        class AddUser extends AsyncTask<Void, Void, String> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(Registrasi.this, "Menambahkan...", "Tunggu...", false, false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(Registrasi.this, s, Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Registrasi.this,Login.class);
                startActivity(intent);
            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String, String> params = new HashMap<>();
                params.put("email", Email);
                params.put("password", Password);
                params.put("nama", Nama);
                params.put("alamat", Alamat);
                params.put("phone", Phone);
                RequestHandler rh = new RequestHandler();
                String res = rh.sendPostRequest(konfigurasi.URL_REG, params);
                return res;
            }
        }
        AddUser am = new AddUser();
        am.execute();
    }
    }
