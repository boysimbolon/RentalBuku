package com.example.rentalbook;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class Login extends AppCompatActivity {
    private EditText email,password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
    }
    public void login(View V){
        String Email = email.getText().toString().trim();
        String Password = password.getText().toString().trim();

        if (Email.isEmpty() || Password.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Mohon lengkapi semua data", Toast.LENGTH_SHORT).show();
            return;
        }

        Logins loginTask = new Logins(Email, Password);
        loginTask.execute();
    }
    class Logins extends AsyncTask<Void , Void, String> {
        ProgressDialog loading;
        private String namalogin;
        private String passwordlogin;

        // Constructor to pass nama dan password ke AsyncTask
        public Logins(String namalogin, String passwordlogin) {
            this.namalogin = namalogin;
            this.passwordlogin = passwordlogin;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loading = ProgressDialog.show(Login.this, "Logging in...", "Please wait...", false, false);
        }

        @Override
        protected String doInBackground(Void... v) {
            HashMap<String, String> params = new HashMap<>();
            params.put("email", namalogin);
            params.put("password", passwordlogin);

            RequestHandler rh = new RequestHandler();
            String res = rh.sendPostRequest(konfigurasi.URL_LOGIN, params);
            return res;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            // Dismiss progress dialog
            loading.dismiss();
            // Check if the response string is not empty
            if (!s.isEmpty()) {
                konfigurasi.KEY_ID = s;
                Intent intent = new Intent(Login.this, MainActivity.class);
                startActivity(intent);
                finish();
            } else {
                // If response string is empty, show error message
                Toast.makeText(Login.this, "Empty response", Toast.LENGTH_SHORT).show();
            }
        }

    }
    public void regis(View V){
        Intent intent = new Intent(Login.this, Registrasi.class);
        startActivity(intent);
    }
}