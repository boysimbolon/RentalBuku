package com.example.rentalbook;

public class konfigurasi {

    public static final String URL_BASE = "http://10.4.13.222/rentalBuku/";
    public static final String URL_REG = URL_BASE + "registrasi.php";
    public static final String URL_LOGIN = URL_BASE + "login.php";
    public static final String URL_SEWA = URL_BASE + "sewain.php";
    public static final String URL_GET_ALL = URL_BASE + "daftarbuku.php?id=";
    public static final String URL_GET_SEWA = URL_BASE + "daftarmybuku.php?id=";
    public static final String URL_EDIT = URL_BASE + "edit.php";
    public static final String URL_DELETE = URL_BASE + "delete.php";

    public static String KEY_NAMA;
    public static String KEY_ID;
    public static String IdBuku;
    public static String judulBuku;
    public static String penulisBuku;
    public static String genreBuku;
    public static String tahunBuku;
    public static String hargaBuku;
    public static String description;
    public static String tSewa;
    public static String tkembali;
    public static String tglSewa;
    public static String tglkembali;
}